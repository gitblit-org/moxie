/*
  version.h - Version defines.
*/

#define PVERS	L"1.51"         // wide string
#define PVERSA	 "1.51"         // ANSI string (windres 2.16.91 didn't like L)
#define PVERE	L"151"          // wide environment string
#define PVEREA	 "151"          // ANSI environment string
#define PVERB	1,5,1,0 	// binary (resource)
